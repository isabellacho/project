import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;

import javalib.impworld.WorldScene;
import javalib.worldimages.FrameImage;
import javalib.worldimages.LineImage;
import javalib.worldimages.OutlineMode;
import javalib.worldimages.OverlayImage;
import javalib.worldimages.OverlayOffsetImage;
import javalib.worldimages.Posn;
import javalib.worldimages.RectangleImage;
import javalib.worldimages.StarImage;
import javalib.worldimages.TextImage;
import javalib.worldimages.WorldImage;
import tester.Tester;

// examples and tests for LightEmAll game
class ExamplesLightEmAll {
  LightEmAll lea1;
  LightEmAll lea2;
  LightEmAll lea3;
  LightEmAll lea4;
  GamePiece p1;
  GamePiece p2;
  ArrayList<GamePiece> l1;
  ArrayList<Integer> l2;
  Edge e1;
  Edge e2;

  // initializes data to be tested
  void initData() {
    lea1 = new LightEmAll(16, 16, new Random(10));
    lea2 = new LightEmAll(10, 10, new Random(10));
    lea3 = new LightEmAll(3, 3, new Random(10));
    // tests are not run on lea4 so its width and height can be changed for bigBang
    lea4 = new LightEmAll(6, 6);
    l1 = new ArrayList<GamePiece>();
    p1 = new GamePiece(2, 2);
    p2 = new GamePiece(4, 4);
    e1 = new Edge(p1, p2, 4);
    e2 = new Edge(p1, p2, 2);
    l2 = new ArrayList<Integer>(Arrays.asList(1, 0, 3, 5, 7, 2, 6, 9, 4, 8));

  }

  // runs game with bigBang
  void testGame(Tester t) {
    initData();
    // speed of tick rate is set to 1.0 to track time in LightEmAll
    lea4.bigBang(lea4.width * p1.SIZE, lea4.height * p1.SIZE, 1.0);
  }

  void testRotateGamePiece(Tester t) {
    initData();
    p1.left = true;
    t.checkExpect(p1.left, true);
    p1.rotateGamePiece();
    t.checkExpect(p1.left, false);
    t.checkExpect(p1.top, true);
  }

  void testDrawPiece(Tester t) {
    // test for light gray and bottom, left, right line
    initData();
    p1.bottom = true;
    p1.left = true;
    p1.right = true;
    WorldImage piece3 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage horLine = new LineImage(new Posn(p1.SIZE / 2, 0), Color.LIGHT_GRAY);
    WorldImage vertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.LIGHT_GRAY);
    piece3 = new OverlayOffsetImage(vertLine, 0, -1 * p1.SIZE / 4, piece3);
    piece3 = new OverlayOffsetImage(horLine, p1.SIZE / 4, 0, piece3);
    piece3 = new OverlayOffsetImage(horLine, -1 * p1.SIZE / 4, 0, piece3);
    t.checkExpect(p1.drawPiece(), piece3);

    // tests for each different color in gradient with top line
    initData();
    p1.top = true;
    p1.powerLevel = 1;
    WorldImage piece4 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage darkVertLine = new LineImage(new Posn(0, p1.SIZE / 2),
        Color.MAGENTA.darker().darker());
    piece4 = new OverlayOffsetImage(darkVertLine, 0, p1.SIZE / 4, piece4);
    t.checkExpect(p1.drawPiece(), piece4);

    initData();
    p1.top = true;
    p1.powerLevel = 3;
    WorldImage piece5 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage darkMVertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.MAGENTA.darker());
    piece5 = new OverlayOffsetImage(darkMVertLine, 0, p1.SIZE / 4, piece5);
    t.checkExpect(p1.drawPiece(), piece5);

    initData();
    p1.top = true;
    p1.powerLevel = 5;
    WorldImage piece6 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage dBlueVertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.BLUE.darker());
    piece6 = new OverlayOffsetImage(dBlueVertLine, 0, p1.SIZE / 4, piece6);
    t.checkExpect(p1.drawPiece(), piece6);

    initData();
    p1.top = true;
    p1.powerLevel = 7;
    WorldImage piece1 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage blueVertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.BLUE);
    piece1 = new OverlayOffsetImage(blueVertLine, 0, p1.SIZE / 4, piece1);
    t.checkExpect(p1.drawPiece(), piece1);

    initData();
    p1.top = true;
    p1.powerLevel = 9;
    WorldImage piece7 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage dCyanVertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.CYAN.darker());
    piece7 = new OverlayOffsetImage(dCyanVertLine, 0, p1.SIZE / 4, piece7);
    t.checkExpect(p1.drawPiece(), piece7);

    initData();
    p1.top = true;
    p1.powerStation = true;
    p1.powerLevel = 100;
    WorldImage piece2 = new FrameImage(
        new RectangleImage(p1.SIZE, p1.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage powerStation = new StarImage(p1.SIZE / 2, OutlineMode.SOLID, Color.CYAN);
    WorldImage cyanVertLine = new LineImage(new Posn(0, p1.SIZE / 2), Color.CYAN);
    piece2 = new OverlayOffsetImage(cyanVertLine, 0, p1.SIZE / 4, piece2);
    piece2 = new OverlayImage(powerStation, piece2);
    t.checkExpect(p1.drawPiece(), piece2);

  }

  void testInitializeBoard(Tester t) {
    initData();
    t.checkExpect(lea1.nodes.size(), 256);
    t.checkExpect(lea2.nodes.size(), 100);
  }

  void testInitializeNeighbors(Tester t) {
    initData();
    lea1.fractalGenerate(0, lea1.width, 0, lea1.height);
    lea2.initializeNeighbors();
    GamePiece gp1 = lea2.board.get(0).get(0);
    GamePiece gp2 = lea2.board.get(0).get(1);
    t.checkExpect(gp1.connected.contains(gp2), false);
  }

  void testAddNeighbors(Tester t) {
    initData();
    GamePiece gp = lea1.board.get(0).get(0);
    t.checkExpect(p1.connected.contains(gp), false);
    t.checkExpect(gp.connected.contains(p1), false);
    lea1.addNeighbors(p1, gp);
    t.checkExpect(p1.connected.contains(gp), true);
    t.checkExpect(gp.connected.contains(p1), true);
  }

  void testPlacePower(Tester t) {
    initData();
    lea1.fractalGenerate(0, lea1.width, 0, lea1.height);
    t.checkExpect(lea1.powerCol, 8);
    t.checkExpect(lea1.powerRow, 0);
    lea2.fractalGenerate(0, lea2.width, 0, lea2.height);
    t.checkExpect(lea2.powerRow, 0);
    t.checkExpect(lea2.powerCol, 5);
  }

  void testInitializeRadius(Tester t) {
    initData();
    lea1.initializeRadius();
    t.checkExpect(lea1.radius, 32);
    lea2.initializeRadius();
    t.checkExpect(lea2.radius, 17);
  }

  void testFindLastPiece(Tester t) {
    initData();
    GamePiece lea2LP = lea2.board.get(2).get(8);
    t.checkExpect(lea2.findLastPiece(), lea2LP);
  }

  void testFindDiameter(Tester t) {
    initData();
    GamePiece gp = lea2.board.get(2).get(1);
    t.checkExpect(lea2.findDiameter(gp), 30);
  }

  void testFractalGenerate(Tester t) {
    initData();
    lea2.fractalGenerate(0, lea2.width, 0, lea2.height);
    for (GamePiece gp : lea2.nodes) {
      boolean reached = gp.top || gp.bottom || gp.left || gp.right;
      t.checkExpect(reached, true);
    }
    t.checkExpect(lea2.board.get(0).get(0).bottom, true);
    lea2.fractalGenerate(0, 1, 0, 1);
    t.checkExpect(lea2.board.get(0).get(0).bottom, true);
  }

  void testManualGenerate(Tester t) {
    initData();
    lea1.manualGenerate();

    t.checkExpect(lea1.board.get(0).get(0).left, false);
    t.checkExpect(lea1.board.get(0).get(0).bottom, true);
    t.checkExpect(lea1.board.get(1).get(0).top, true);
    t.checkExpect(lea1.board.get(2).get(0).top, false);
    t.checkExpect(lea1.board.get(2).get(1).top, true);
    t.checkExpect(lea1.board.get(2).get(1).bottom, true);
    t.checkExpect(lea1.board.get(2).get(1).right, false);
  }

  void testMakeScene(Tester t) {
    initData();
    WorldScene scene = new WorldScene(0, 0);
    for (GamePiece gp : lea2.nodes) {
      scene.placeImageXY(gp.drawPiece(), gp.col * gp.SIZE + gp.SIZE / 2,
          gp.row * gp.SIZE + gp.SIZE / 2);
      WorldImage score = new TextImage("Score: " + lea2.score, gp.SIZE / 4, Color.GREEN);
      scene.placeImageXY(score, lea2.width * gp.SIZE - 35, lea2.height * gp.SIZE - 10);
      WorldImage timeImage = new TextImage("Time: " + lea2.time, gp.SIZE / 4, Color.GREEN);
      scene.placeImageXY(timeImage, gp.SIZE - 20, lea2.height * gp.SIZE - 10);
    }
    t.checkExpect(lea2.makeScene(), scene);
  }

  void testOnMouseClicked(Tester t) {
    initData();
    lea1.fractalGenerate(0, lea1.width, 0, lea1.height);
    t.checkExpect(lea1.nodes.get(16).powerLevel, 0);
    lea1.onMouseClicked(new Posn(20, 30));
    t.checkExpect(lea1.board.get(2).get(0).powerLevel, 0);
  }

  void testOnTick(Tester t) {
    initData();
    t.checkExpect(lea1.time, 0);
    lea1.onTick();
    t.checkExpect(lea1.time, 1);
    lea1.onTick();
    t.checkExpect(lea1.time, 2);
  }

  void testWinGame(Tester t) {
    initData();
    t.checkExpect(lea1.winGame(), false);
    lea1.fractalGenerate(0, lea1.width, 0, lea1.height);
    lea1.turnOnBoard();
    t.checkExpect(lea1.winGame(), false);
  }

  void testLastScene(Tester t) {
    initData();
    WorldScene scene = lea1.makeScene();
    WorldImage winText = new TextImage("You win!", 40, Color.GREEN);
    scene.placeImageXY(winText, lea1.width * 40 / 2, lea1.height * 40 / 2);
    t.checkExpect(lea1.lastScene("win"), scene);
  }

  void testOnKeyEvent(Tester t) {
    initData();
    lea1.fractalGenerate(0, lea1.width, 0, lea1.height);

    lea1.onKeyEvent("up");
    t.checkExpect(lea1.powerRow, 0);
    lea1.onKeyEvent("down");
    t.checkExpect(lea1.powerRow, 1);
    lea1.onKeyEvent("left");
    t.checkExpect(lea1.powerCol, (lea1.width / 2));
    lea1.onKeyEvent("right");
    t.checkExpect(lea1.powerCol, (lea1.width / 2) + 1);
  }

  void testMoveStar(Tester t) {
    initData();
    t.checkExpect(lea2.board.get(0).get(0).powerStation, false);
    t.checkExpect(lea2.board.get(lea2.powerCol).get(lea2.powerRow).powerStation, true);
    lea1.moveStar(lea2.board.get(lea2.powerCol).get(lea2.powerRow), lea2.board.get(0).get(0));
    t.checkExpect(lea2.powerCol, 5);
    t.checkExpect(lea2.powerRow, 0);
    t.checkExpect(lea2.board.get(0).get(0).powerStation, true);
    t.checkExpect(lea2.board.get(lea2.powerCol).get(lea2.powerRow).powerStation, false);

  }

  void testTurnOnBoard(Tester t) {
    initData();
    lea2.board = new ArrayList<>();
    lea2.nodes = new ArrayList<>();
    lea2.initializeBoard();
    lea2.fractalGenerate(0, lea2.width, 0, lea2.height);
    lea2.placePower();
    lea2.radius = 100;
    lea2.turnOnBoard();
    for (GamePiece gp : lea2.nodes) {
      t.checkExpect(gp.powerLevel > 0, true);
    }
  }

  void testTurnOnGP(Tester t) {
    initData();
    GamePiece gp1 = lea2.board.get(2).get(2);
    t.checkExpect(gp1.powerLevel, 0);
    lea2.turnOnGP(gp1, 1);
    t.checkExpect(gp1.powerLevel, 1);

  }

  void testRandomizeBoard(Tester t) {
    initData();
    lea3.randomizeBoard();
    t.checkExpect(lea3.nodes.get(0).left, true);
    t.checkExpect(lea3.nodes.get(1).right, true);
    t.checkExpect(lea3.nodes.get(2).top, false);
    t.checkExpect(lea3.nodes.get(3).left, true);
    t.checkExpect(lea3.nodes.get(3).right, false);
    t.checkExpect(lea3.nodes.get(3).top, true);
    t.checkExpect(lea3.nodes.get(4).left, true);
    t.checkExpect(lea3.nodes.get(4).right, false);
    t.checkExpect(lea3.nodes.get(4).top, true);

  }

  void testMakeRandom(Tester t) {
    initData();
    lea3.makeRandom();
    GamePiece p0 = lea3.board.get(0).get(0);
    GamePiece p1 = lea3.board.get(0).get(1);

    t.checkExpect(p0.top, false);
    t.checkExpect(p0.bottom, false);
    t.checkExpect(p0.left, false);
    t.checkExpect(p0.right, true);
    t.checkExpect(p1.top, false);
    t.checkExpect(p1.bottom, true);
    t.checkExpect(p1.left, false);
    t.checkExpect(p1.right, true);

  }

  void testMakeTree(Tester t) {
    initData();
    lea1.mst = new ArrayList<>();
    lea2.mst = new ArrayList<>();
    lea3.mst = new ArrayList<>();

    lea1.makeTree();
    lea2.makeTree();
    lea3.makeTree();
    t.checkExpect(lea1.mst.size(), 255);
    t.checkExpect(lea2.mst.size(), 99);
    t.checkExpect(lea3.mst.size(), 8);
  }

  void testFindValue(Tester t) {
    initData();
    HashMap<Integer, Integer> test = new HashMap<>();
    for (int i = 0; i < 10; i++) {
      test.put(i, 5);
    }

    for (int j = 0; j < 10; j++) {
      t.checkExpect(lea3.findValue(test, j), 5);
    }

    HashMap<Integer, Integer> test2 = new HashMap<>();
    for (int i = 0; i < 9; i++) {
      test2.put(i, i + 1);
    }
    test2.put(9, 9);
    t.checkExpect(lea3.findValue(test2, 0), 9);
  }

  void testMakeEdges(Tester t) {
    initData();
    ArrayList<Edge> edges = lea3.makeEdges();
    GamePiece gp0 = lea3.board.get(0).get(0);
    GamePiece gp1 = lea3.board.get(0).get(1);
    GamePiece gp2 = lea3.board.get(1).get(0);
    t.checkExpect(edges.get(0).fromNode, gp0);
    t.checkExpect(edges.get(0).toNode, gp2);
    t.checkExpect(edges.get(1).fromNode, gp0);
    t.checkExpect(edges.get(1).toNode, gp1);

  }

  void testMakeMap(Tester t) {
    initData();
    HashMap<Integer, Integer> lea3Map = lea3.makeMap();
    HashMap<Integer, Integer> test = new HashMap<>();

    for (int i = 0; i < lea3.nodes.size(); i++) {
      test.put(i, i);
    }
    t.checkExpect(lea3Map, test);

    HashMap<Integer, Integer> lea2Map = lea2.makeMap();
    HashMap<Integer, Integer> test2 = new HashMap<>();

    for (int j = 0; j < lea2.nodes.size(); j++) {
      test2.put(j, j);
    }

    t.checkExpect(lea2Map, test2);

  }

  // HeapSort tests
  void testHeapSort(Tester t) {
    initData();
    HeapSort<Integer> hs = new HeapSort<>();
    t.checkExpect(hs.heapSort(l2, new CompareInts()),
        new ArrayList<Integer>(Arrays.asList(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)));
  }

  void testMakeHeap(Tester t) {
    initData();

    HeapSort<Integer> hs = new HeapSort<>();
    hs.makeHeap(l2, new CompareInts());

    t.checkExpect(l2, new ArrayList<Integer>(Arrays.asList(9, 8, 6, 5, 7, 1, 2, 0, 4, 3)));
  }

  void testSwap(Tester t) {
    initData();
    ArrayList<Integer> l = new ArrayList<Integer>(Arrays.asList(3, 4));
    HeapSort<Integer> hs = new HeapSort<>();
    hs.swap(l, 0, 1);
    t.checkExpect(l.get(0), 4);
    t.checkExpect(l.get(1), 3);
  }

  void testUpHeap(Tester t) {
    initData();
    HeapSort<Integer> hs = new HeapSort<>();
    hs.upHeap(l2, new CompareInts(), 0);
    t.checkExpect(l2, l2);
    hs.upHeap(l2, new CompareInts(), 5);
    t.checkExpect(l2, new ArrayList<Integer>(Arrays.asList(1, 0, 3, 5, 7, 2, 6, 9, 4, 8)));
  }

  void testDownHeap(Tester t) {
    initData();
    HeapSort<Integer> hs = new HeapSort<>();
    hs.downHeap(l2, new CompareInts(), 2, 0);
    t.checkExpect(l2, l2);
    hs.upHeap(l2, new CompareInts(), 5);
    t.checkExpect(l2, new ArrayList<Integer>(Arrays.asList(1, 0, 3, 5, 7, 2, 6, 9, 4, 8)));
  }

  void testCompareInts(Tester t) {
    initData();
    HeapSort<Integer> hs = new HeapSort<>();
    hs.makeHeap(l2, new CompareInts());
    t.checkExpect(l2, new ArrayList<Integer>(Arrays.asList(9, 8, 6, 5, 7, 1, 2, 0, 4, 3)));
    CompareInts ci = new CompareInts();
    t.checkExpect(ci.compare(4, 2), 2);

  }

  void testSortList(Tester t) {
    HeapSort<Integer> hs = new HeapSort<>();
    CompareInts ci = new CompareInts();
    hs.sortList(l2, ci);
    hs.swap(l2, 0, l2.size() - 1 - 0);
    hs.downHeap(l2, ci, 0, l2.size() - 1 - 0);
    t.checkExpect(l2, new ArrayList<Integer>(Arrays.asList(5, 2, 9, 7, 3, 6, 1, 4, 8, 0)));
  }

  void testCompareEdgeWeights(Tester t) {
    initData();
    CompareEdgeWeights cew = new CompareEdgeWeights();
    t.checkExpect(cew.compare(e1, e2), 2);
  }
}