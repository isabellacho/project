import java.util.ArrayList;
import java.util.Comparator;

class HeapSort<T> {

  // sorts the list using heapsort
  public ArrayList<T> heapSort(ArrayList<T> l, Comparator<T> c) {
    makeHeap(l, c);
    sortList(l, c);

    return l;
  }

  // constructs heap in list
  public void makeHeap(ArrayList<T> l, Comparator<T> c) {
    for (int i = 0; i < l.size(); i++) {
      upHeap(l, c, i);
    }
  }

  // swaps two values at given indexes
  public void swap(ArrayList<T> l, int indexOne, int indexTwo) {
    T temp = l.get(indexTwo);
    l.set(indexTwo, l.get(indexOne));
    l.set(indexOne, temp);
  }

  // up heap value in list given index, list, and comparator
  public void upHeap(ArrayList<T> l, Comparator<T> c, int indexVal) {
    if (indexVal == 0) {
      return;
    }

    int indexParent = (indexVal - 1) / 2;
    if (c.compare(l.get(indexVal), l.get(indexParent)) > 0) {
      swap(l, indexVal, indexParent);
      upHeap(l, c, indexParent);
    }
  }

  // down heap value in the list without exceeding max index
  public void downHeap(ArrayList<T> l, Comparator<T> c, int indexVal, int indexMax) {
    int indexLChild = 2 * indexVal + 1;
    int indexRChild = 2 * indexVal + 2;
    int indexLargestChild;

    if (indexLChild >= indexMax) {
      return;
    }
    else if (indexRChild >= indexMax) {
      indexLargestChild = indexLChild;
    }
    else {
      if (c.compare(l.get(indexLChild), l.get(indexRChild)) > 0) {
        indexLargestChild = indexLChild;
      }
      else {
        indexLargestChild = indexRChild;
      }
    }
    if (c.compare(l.get(indexVal), l.get(indexLargestChild)) < 0) {
      swap(l, indexVal, indexLargestChild);
      downHeap(l, c, indexLargestChild, indexMax);
    }
  }

  // sort a list that has already been ordered into heap
  public void sortList(ArrayList<T> l, Comparator<T> c) {
    for (int i = 0; i < l.size(); i++) {
      swap(l, 0, l.size() - 1 - i);
      downHeap(l, c, 0, l.size() - 1 - i);
    }
  }

}

class CompareEdgeWeights implements Comparator<Edge> {
  // compares the weights of two edges
  public int compare(Edge e1, Edge e2) {
    return e1.weight - e2.weight;
  }
}

class CompareInts implements Comparator<Integer> {
  // compares values of two integers
  public int compare(Integer first, Integer second) {
    return first - second;
  }
}