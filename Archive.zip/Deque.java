import tester.*;

// this Deque implementation is taken directly from our
// Assignment 7 submission

interface IPred<T> {
  // pred is applied to t
  boolean apply(T t);
}

// checks if string is name sean
class IsSean implements IPred<String> {
  public boolean apply(String t) {
    return t.contentEquals("sean");
  }
}

// checks if string contains letter "a"
class HasA implements IPred<String> {
  public boolean apply(String t) {
    return t.contains("a");
  }
}

class Deque<T> {
  Sentinel<T> header;

  Deque() {
    this.header = new Sentinel<T>();
  }

  Deque(Sentinel<T> value) {
    this.header = value;
  }

  // counts the number of nodes in a list Deque,
  // not including the header node
  int size() {
    return this.header.countSize(0);
  }

  // consumes a value of type T and inserts it at the front of the list
  void addAtHead(T value) {
    this.header.addValueHead(value);
  }

  // consumes a value of type T and inserts it at the tail of the list
  void addAtTail(T value) {
    this.header.addValueTail(value);
  }

  // removes the first node from this Deque
  T removeFromHead() {
    if (this.size() == 0) {
      throw new RuntimeException("This Deque is empty. And we love our TA's!");
    }
    else {
      return header.removeFromHead();
    }
  }

  // removes the last node from this Deque
  T removeFromTail() {
    if (this.size() == 0) {
      throw new RuntimeException("This Deque is empty. And we still love our TA's!");
    }
    else {
      return header.removeFromTail();
    }
  }

  // produces the first node in this Deque for which the given predicate returns
  // true
  ANode<T> find(IPred<T> pred) {
    return this.header.headerFind(pred);
  }

  // removes the given node from this Deque
  void removeNode(ANode<T> t) {
    t.delete();
  }
}

abstract class ANode<T> {
  ANode<T> next;
  ANode<T> prev;

  // sets next to given node
  void setNext(ANode<T> node) {
    this.next = node;
  }

  // sets previous to given node
  void setPrevious(ANode<T> node) {
    this.prev = node;
  }

  // helps count number of nodes
  int countSize(int count) {
    return this.next.countSize(++count);
  }

  public void delete() {
    this.next.setPrevious(this.prev);
    this.prev.setNext(this.next);
  }

  abstract ANode<T> helpFind(IPred<T> pred);

}

class Node<T> extends ANode<T> {
  T data;

  Node(T data) {
    this.data = data;
    this.next = null;
    this.prev = null;
  }

  Node(T data, ANode<T> next, ANode<T> prev) {
    this.data = data;
    this.next = next;
    this.prev = prev;
    if (next == null) {
      throw new IllegalArgumentException("Node should not be null.");
    }
    else if (prev == null) {
      throw new IllegalArgumentException("Node should not be null.");
    }
    else {
      next.setPrevious(this);
      prev.setNext(this);
    }
  }

  // produces first node in list that passes predicate
  ANode<T> helpFind(IPred<T> pred) {
    if (pred.apply(this.data)) {
      return this;
    }
    else {
      return this.next.helpFind(pred);
    }
  }

  void removeHelp() {
    this.delete();
  }
}

class Sentinel<T> extends ANode<T> {

  Sentinel() {
    this.next = this;
    this.prev = this;
  }

  // helps count number of nodes
  // returns zero because does not count sentinel
  int countSize(int count) {
    if (count > 0) {
      return count - 1;
    }
    else {
      return super.countSize(count);
    }
  }

  // Effect: inserts value at the head of a list
  void addValueHead(T value) {
    new Node<T>(value, this.next, this);
  }

  // Effect: consumes a value of type T and inserts it at the tail of the list
  void addValueTail(T value) {
    new Node<T>(value, this, this.prev);
  }

  // helps remove the first node from this Deque
  T removeFromHead() {
    Node<T> temp = (Node<T>) this.next;
    this.next.delete();
    return temp.data;
  }

  // helps remove the last node from this Deque
  T removeFromTail() {
    Node<T> temp = (Node<T>) this.prev;
    this.prev.delete();
    return temp.data;
  }

  ANode<T> headerFind(IPred<T> pred) {
    return this.next.helpFind(pred);
  }

  ANode<T> helpFind(IPred<T> pred) {
    return this;
  }

  public void delete() {
    // we don't want to delete a Sentinel
  }

}

class ExamplesDeque {

  Sentinel<String> sentinel1;
  Node<String> node1;
  Node<String> node2;
  Node<String> node3;
  Node<String> node4;

  Sentinel<String> sentinel2;
  Node<String> node5;
  Node<String> node6;
  Node<String> node7;
  Node<String> node8;
  Node<String> node9;

  Sentinel<String> sentinel3;
  Node<String> node10;
  Node<String> node11;

  Deque<String> deque1;
  Deque<String> deque2;
  Deque<String> deque3;
  Deque<String> deque4;

  void initData() {
    this.sentinel1 = new Sentinel<String>();
    this.node1 = new Node<String>("abc", sentinel1, sentinel1);
    this.node2 = new Node<String>("bcd", sentinel1, node1);
    this.node3 = new Node<String>("cde", sentinel1, node2);
    this.node4 = new Node<String>("def", sentinel1, node3);

    this.sentinel2 = new Sentinel<String>();
    this.node5 = new Node<String>("wee", sentinel2, sentinel2);
    this.node6 = new Node<String>("luv", sentinel2, node5);
    this.node7 = new Node<String>("our", sentinel2, node6);
    this.node8 = new Node<String>("tas", sentinel2, node7);
    this.node9 = new Node<String>("xox", sentinel2, node8);

    this.sentinel3 = new Sentinel<String>();
    this.node10 = new Node<String>("sean", sentinel3, sentinel3);
    this.node11 = new Node<String>("isabella", sentinel3, this.node10);

    this.deque1 = new Deque<String>();
    this.deque2 = new Deque<String>(this.sentinel1);
    this.deque3 = new Deque<String>(this.sentinel2);
    this.deque4 = new Deque<String>(this.sentinel3);
  }

  void testConstructor(Tester t) {
    t.checkConstructorException(new IllegalArgumentException("Node should not be null."), "Node",
        "abc", null, null);
  }

  void testCountSize(Tester t) {
    initData();
    t.checkExpect(this.node2.countSize(1), 3);
    t.checkExpect(this.sentinel1.prev.countSize(0), 0);
  }

  void testSize(Tester t) {
    initData();
    t.checkExpect(deque1.size(), 0);
    t.checkExpect(deque3.size(), 5);
    t.checkExpect(deque4.size(), 2);
  }

  void testSetPrevious(Tester t) {
    initData();
    sentinel1.setPrevious(this.node1);
    t.checkExpect(this.sentinel1.prev, this.node1);
  }

  void testSetNext(Tester t) {
    initData();
    sentinel1.setNext(node1);
    t.checkExpect(this.sentinel1.next, this.node1);
  }

  void testAddAtHead(Tester t) {
    initData();
    this.deque1.addAtHead("hi");
    t.checkExpect(this.deque1.header.next, new Node<String>("hi", this.sentinel1, this.sentinel1));
    t.checkExpect(this.sentinel1.next, new Node<String>("hi", this.sentinel1, this.sentinel1));
  }

  void testAddAtTail(Tester t) {
    initData();
    Node<String> byeNode = new Node<String>("bye", this.sentinel1, this.sentinel1);
    this.deque1.addAtTail("bye");
    t.checkExpect(this.deque1.header.prev, byeNode);
    this.deque2.addAtTail("yo");
    t.checkExpect(this.deque2.header.prev, new Node<String>("yo", this.sentinel1, byeNode));
  }

  void testRemoveFromHead(Tester t) {
    initData();
    this.deque4.removeFromHead();
    t.checkExpect(this.deque4.removeFromHead(), "isabella");
  }

  void testRemoveFromTail(Tester t) {
    initData();
    this.deque4.removeFromTail();
    t.checkExpect(this.deque4.removeFromTail(), "sean");
  }

  void testFind(Tester t) {
    initData();
    t.checkExpect(this.deque4.find(new IsSean()), node10);
    t.checkExpect(this.deque2.find(new HasA()), node1);
  }

  void testRemoveNode(Tester t) {
    initData();
    this.deque2.removeNode(node1);
    t.checkExpect(this.deque2.header.next, node2);
  }

  void testDelete(Tester t) {
    this.sentinel1.delete();
    t.checkExpect(this.deque2.header, this.sentinel1);
  }

}