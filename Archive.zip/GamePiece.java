import java.awt.Color;
import java.util.ArrayList;
import javalib.worldimages.*;

// game pieces of LightEmAll
class GamePiece {
  // set size of GamePieces
  final int SIZE = 60;
  // in logical coordinates, with the origin
  // at the top-left corner of the screen
  int row;
  int col;
  // whether this GamePiece is connected to the
  // adjacent left, right, top, or bottom pieces
  boolean left;
  boolean right;
  boolean top;
  boolean bottom;
  // whether the power station is on this piece
  boolean powerStation;
  ArrayList<GamePiece> connected;
  // represents piece position
  int piecePos = 0;
  // determines if GP is connected to powerStation
  int powerLevel;

  GamePiece(int row, int column) {
    this.row = row;
    this.col = column;
    this.left = false;
    this.right = false;
    this.top = false;
    this.bottom = false;
    this.powerStation = false;
    this.connected = new ArrayList<>();
    this.piecePos = 0;
    this.powerLevel = 0;

  }

  GamePiece(int row, int column, int piecePos) {
    this.row = row;
    this.col = column;
    this.left = false;
    this.right = false;
    this.top = false;
    this.bottom = false;
    this.powerStation = false;
    this.connected = new ArrayList<>();
    this.piecePos = piecePos;
    this.powerLevel = 0;

  }

  // rotates current piece
  void rotateGamePiece() {
    boolean tTemp = this.top;
    boolean bTemp = this.bottom;
    boolean rTemp = this.right;
    boolean lTemp = this.left;

    this.top = lTemp;
    this.bottom = rTemp;
    this.right = tTemp;
    this.left = bTemp;
  }

  // draws this piece accordingly with line color gray or yellow
  public WorldImage drawPiece() {
    // line color default to gray
    Color line = Color.LIGHT_GRAY;

    // implements gradient coloring as wire gets further from power station
    if (this.powerLevel > 0) {
      if (this.powerLevel == 1 || this.powerLevel == 2) {
        line = Color.MAGENTA.darker().darker();
      }
      else if (this.powerLevel == 3 || this.powerLevel == 4) {
        line = Color.MAGENTA.darker();
      }
      else if (this.powerLevel == 5 || this.powerLevel == 6) {
        line = Color.BLUE.darker();
      }
      else if (this.powerLevel == 7 || this.powerLevel == 8) {
        line = Color.BLUE;
      }
      else if (this.powerLevel == 9 || this.powerLevel == 10) {
        line = Color.CYAN.darker();
      }
      else {
        line = Color.CYAN;
      }

    }

    WorldImage piece = new FrameImage(
        new RectangleImage(this.SIZE, this.SIZE, OutlineMode.SOLID, Color.DARK_GRAY));
    WorldImage powerStation = new StarImage(this.SIZE / 2, OutlineMode.SOLID, Color.CYAN);
    WorldImage vertLine = new LineImage(new Posn(0, this.SIZE / 2), line);
    WorldImage horLine = new LineImage(new Posn(this.SIZE / 2, 0), line);
    // draws appropriate wiring on GamePiece
    if (this.top) {
      piece = new OverlayOffsetImage(vertLine, 0, this.SIZE / 4, piece);

    }
    if (this.bottom) {
      piece = new OverlayOffsetImage(vertLine, 0, -1 * this.SIZE / 4, piece);
    }
    if (this.left) {
      piece = new OverlayOffsetImage(horLine, this.SIZE / 4, 0, piece);
    }
    if (this.right) {
      piece = new OverlayOffsetImage(horLine, -1 * this.SIZE / 4, 0, piece);
    }
    if (this.powerStation) {
      piece = new OverlayImage(powerStation, piece);
    }
    return piece;
  }

}