import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

import javalib.impworld.*;
import java.awt.Color;
import javalib.worldimages.*;

// LightEmAll World
class LightEmAll extends World {
  // a list of columns of GamePieces,
  // i.e., represents the board in column-major order
  ArrayList<ArrayList<GamePiece>> board;
  // a list of all nodes
  ArrayList<GamePiece> nodes;
  // a list of edges of the minimum spanning tree
  ArrayList<Edge> mst;
  // the width and height of the board
  int width;
  int height;
  // the current location of the power station,
  // as well as its effective radius
  int powerRow;
  int powerCol;
  int radius;
  int rows;
  int columns;
  Random rand;
  int score;
  int time;

  LightEmAll(int width, int height) {
    this(width, height, new Random());
  }

  LightEmAll(int width, int height, Random rand) {
    this.width = width;
    this.height = height;
    this.board = new ArrayList<>();
    this.nodes = new ArrayList<>();
    this.mst = new ArrayList<>();
    this.powerRow = 0;
    this.powerCol = 0;
    this.radius = 0;
    this.rand = rand;
    this.score = 0;
    this.time = 0;

    // initializes appropriate board
    this.initializeBoard();

    // initializes list of neighbors for each GamePiece representing connections
    this.initializeNeighbors();

    // places powerStation in required location
    this.placePower();

    // initializes radius using breadth-first search
    this.initializeRadius();

    // randomize orientation of GamePieces
    this.randomizeBoard();

    // lights up board according to location of powerStation and
    // connection of pieces
    this.turnOnBoard();
  }

  // creates scene with board with GamePieces
  public WorldScene makeScene() {
    WorldScene scene = getEmptyScene();
    for (int i = 0; i < this.width; i++) {
      for (int j = 0; j < this.height; j++) {
        // draws GamePieces
        GamePiece gp = this.board.get(i).get(j);
        scene.placeImageXY(gp.drawPiece(), i * gp.SIZE + gp.SIZE / 2, j * gp.SIZE + gp.SIZE / 2);
        // draws score in bottom right
        WorldImage score = new TextImage("Score: " + this.score, gp.SIZE / 4, Color.GREEN);
        scene.placeImageXY(score, this.width * gp.SIZE - 40, this.height * gp.SIZE - 10);
        // draws time in bottom left
        WorldImage timeImage = new TextImage("Time: " + this.time, gp.SIZE / 4, Color.GREEN);
        scene.placeImageXY(timeImage, gp.SIZE - 20, this.height * gp.SIZE - 10);
      }
    }
    return scene;
  }

  // rotates piece when clicked
  public void onMouseClicked(Posn p) {
    Posn pos = new Posn(p.x / this.nodes.get(0).SIZE, p.y / this.nodes.get(0).SIZE);
    if (pos.x >= this.width || pos.y >= this.height) {
      return;
    }
    GamePiece gp = this.board.get(pos.x).get(pos.y);

    // rotates piece on click
    gp.rotateGamePiece();

    // powers board on click
    this.turnOnBoard();

    // adds one to the score each click
    this.score++;

    // win condition on click
    if (this.winGame()) {
      this.endOfWorld("win");
    }
  }

  @Override
  // used to update time by adding one per second
  public void onTick() {
    this.time++;
  }

  // returns true if all GP are powered
  public boolean winGame() {
    for (GamePiece gp : this.nodes) {
      if (gp.powerLevel == 0) {
        return false;
      }
    }
    return true;
  }

  // returns the win scene
  public WorldScene lastScene(String message) {
    WorldScene scene = this.makeScene();
    int dimensions = this.nodes.get(0).SIZE;
    if (message.equals("win")) {
      WorldImage winText = new TextImage("You win!", dimensions, Color.GREEN);
      WorldImage scoreText = new TextImage("Score: " + this.score, dimensions / 2, Color.GREEN);
      WorldImage combined = new AboveImage(winText, scoreText);
      scene.placeImageXY(combined, (this.width * dimensions) / 2, (this.height * dimensions) / 2);
    }
    return scene;
  }

  // moves the powerStation according to key press
  public void onKeyEvent(String ke) {
    GamePiece oldGP = this.board.get(this.powerCol).get(this.powerRow);
    GamePiece newGP;
    if (ke.equals("left")) {
      if (this.powerCol != 0) {
        newGP = this.board.get(this.powerCol - 1).get(this.powerRow);

        if (oldGP.left && newGP.right) {
          this.moveStar(oldGP, newGP);
          this.score++;
        }
      }
    }
    if (ke.equals("right")) {
      if (this.powerCol != this.width - 1) {
        newGP = this.board.get(this.powerCol + 1).get(this.powerRow);
        if (oldGP.right && newGP.left) {
          this.moveStar(oldGP, newGP);
          this.score++;
        }
      }
    }
    if (ke.equals("down")) {
      if (this.powerRow != this.height - 1) {
        newGP = this.board.get(this.powerCol).get(this.powerRow + 1);
        if (oldGP.bottom && newGP.top) {
          this.moveStar(oldGP, newGP);
          this.score++;
        }
      }
    }
    if (ke.equals("up")) {
      if (this.powerRow != 0) {
        newGP = this.board.get(this.powerCol).get(this.powerRow - 1);
        if (oldGP.top && newGP.bottom) {
          this.moveStar(oldGP, newGP);
          this.score++;
        }
      }
    }

    // powers board on key press
    this.turnOnBoard();

    // win condition on key press
    if (this.winGame()) {
      this.endOfWorld("win");
    }
  }

  // creates all GamePieces in game
  public void initializeBoard() {
    int piecePos = 0;
    for (int i = 0; i < this.width; i++) {
      this.board.add(new ArrayList<GamePiece>());
      ArrayList<GamePiece> col = this.board.get(i);

      for (int j = 0; j < this.height; j++) {
        GamePiece piece = new GamePiece(j, i, piecePos);
        piecePos = piecePos + 1;

        col.add(piece);
        this.nodes.add(piece);
      }
    }

    // generates random board pattern
    this.makeRandom();

  }

  // initialize neighbors of all GamePieces
  public void initializeNeighbors() {
    for (int i = 0; i < this.width; i++) {
      for (int j = 0; j < this.height; j++) {
        GamePiece piece = this.board.get(i).get(j);

        if (piece.bottom) {
          if (piece.row == this.height - 1) {
            // if is empty to skip the case
          }
          else {
            GamePiece bottomPiece = this.board.get(i).get(j + 1);

            if (bottomPiece.top) {
              this.addNeighbors(piece, bottomPiece);
            }
          }
        }
        if (piece.right) {
          if (piece.col == this.width - 1) {
            // if is empty to skip the case
          }
          else {
            GamePiece rightPiece = this.board.get(i + 1).get(j);

            if (rightPiece.left) {
              this.addNeighbors(piece, rightPiece);
            }
          }
        }
      }
    }
  }

  // adds given first and second game piece their respective list of neighbors
  public void addNeighbors(GamePiece first, GamePiece second) {
    first.connected.add(second);
    second.connected.add(first);

  }

  // initializes radius of board
  public void initializeRadius() {

    // returns last piece of breadth-first search
    GamePiece lastPiece = this.findLastPiece();

    // returns depth of breadth-first search
    int diameter = this.findDiameter(lastPiece);

    // uses diameter to get radius
    this.radius = (diameter / 2) + 1;
  }

  // finds last piece in breadth-first search
  public GamePiece findLastPiece() {
    // tracks the GP already seen
    ArrayList<GamePiece> gpSeen = new ArrayList<>();

    // tracks GP left
    Queue<GamePiece> gpCheck = new Queue<>();

    GamePiece startingGP = this.board.get(powerCol).get(powerRow);
    gpCheck.add(startingGP);

    GamePiece storedGP = startingGP;
    while (!gpCheck.isEmpty()) {
      GamePiece next = gpCheck.remove();
      storedGP = next;

      if (gpSeen.contains(next)) {
        // empty if to skip case purposely
      }
      else {
        for (GamePiece gp : next.connected) {
          gpCheck.add(gp);
        }
      }
      gpSeen.add(next);
    }
    return storedGP;
  }

  // return depth of breadth-first search of board
  public int findDiameter(GamePiece startingGP) {
    ArrayList<GamePiece> seen = new ArrayList<>();
    // queue to keep the GamePieces left to run through
    Queue<GamePiece> toCheck = new Queue<>();

    int currentLayer = 1;
    int nextLayer = 0;
    int diameter = 0;

    toCheck.add(startingGP);
    while (!toCheck.isEmpty()) {
      GamePiece next = toCheck.remove();
      if (seen.contains(next)) {
        // if is empty to skip case
      }
      else {
        for (GamePiece gp : next.connected) {
          toCheck.add(gp);
          nextLayer++;
        }
      }

      currentLayer--;
      if (currentLayer <= 0) {
        diameter++;
        currentLayer = nextLayer;
        nextLayer = 0;
      }
      seen.add(next);
    }
    return diameter;

  }

  // places the powerStation
  // placed in the center of the top row for fractal generation
  public void placePower() {
    this.powerRow = 0;
    this.powerCol = this.width / 2;
    GamePiece stationPiece = this.board.get(powerCol).get(powerRow);
    stationPiece.powerStation = true;
  }

  // moves star
  public void moveStar(GamePiece oldGP, GamePiece newGP) {
    oldGP.powerStation = false;
    newGP.powerStation = true;
    this.powerCol = newGP.col;
    this.powerRow = newGP.row;
  }

  // randomizes GamePieces
  public void randomizeBoard() {
    for (GamePiece gp : this.nodes) {
      int clicks = this.rand.nextInt(4);
      for (int i = 0; i < clicks; i++) {
        gp.rotateGamePiece();
      }
    }

  }

  // creates a randomly generated board using a MST
  void makeRandom() {

    for (GamePiece gp : this.nodes) {
      gp.top = false;
      gp.bottom = false;
      gp.left = false;
      gp.right = false;
    }
    // makes MST
    this.makeTree();

    for (Edge edge : this.mst) {
      GamePiece from = edge.fromNode;
      GamePiece to = edge.toNode;

      if (from.row < to.row) {
        from.bottom = true;
        to.top = true;
      }

      if (from.row > to.row) {
        from.top = true;
        to.bottom = true;
      }

      if (from.col < to.col) {
        from.right = true;
        to.left = true;
      }

      if (from.col > to.col) {
        from.left = true;
        to.right = true;
      }
    }
  }

  // makes minimum-spanning tree
  void makeTree() {
    // makes all edges
    ArrayList<Edge> edges = this.makeEdges();

    // makes a HashMap initialized in a way where the piecePos of
    // each GamePiece and its representative value are equal
    HashMap<Integer, Integer> values = this.makeMap();

    // makes a heapSort object with methods to sort all edges
    HeapSort<Edge> hs = new HeapSort<>();
    edges = hs.heapSort(edges, new CompareEdgeWeights());

    // tracks current edge in all edges
    int index = 0;

    while (index < edges.size()) {
      Edge next = edges.get(index);
      // finds representative value
      int valFromNode = this.findValue(values, next.fromNode.piecePos);
      int valToNode = this.findValue(values, next.toNode.piecePos);

      // if representative values aren't equal add to tree and union
      if (valFromNode != valToNode) {
        this.mst.add(next);
        values.put(valToNode, valFromNode);
      }
      index++;
    }
  }

  // returns representative value of particular node
  int findValue(HashMap<Integer, Integer> values, int initValue) {
    if (initValue == values.get(initValue)) {
      return initValue;
    }
    else {
      return findValue(values, values.get(initValue));
    }
  }

  // makes edges connecting all GamePieces
  ArrayList<Edge> makeEdges() {
    ArrayList<Edge> edges = new ArrayList<>();

    for (int i = 0; i < this.width; i++) {
      for (int j = 0; j < this.height; j++) {
        GamePiece fromGP = this.board.get(i).get(j);

        // implements a preference for horizontal edges over
        // vertical edges by making roof for nextInt lower
        if (i < this.width - 1) {
          GamePiece rightGP = this.board.get(i + 1).get(j);
          int edgeWeight = this.rand.nextInt(this.width * this.height / 2);
          Edge rightEdge = new Edge(fromGP, rightGP, edgeWeight);
          edges.add(rightEdge);
        }
        if (j < this.height - 1) {
          GamePiece bottomGP = this.board.get(i).get(j + 1);
          int edgeWeight = this.rand.nextInt(this.width * this.height);
          Edge bottomEdge = new Edge(fromGP, bottomGP, edgeWeight);
          edges.add(bottomEdge);
        }
      }
    }
    return edges;
  }

  // makes HashMap in which representative value is equal to key
  HashMap<Integer, Integer> makeMap() {
    HashMap<Integer, Integer> values = new HashMap<>();

    for (GamePiece gp : this.nodes) {
      values.put(gp.piecePos, gp.piecePos);
    }

    return values;
  }

  // initializes connections based on manual patter from part 1
  public void manualGenerate() {
    for (int i = 0; i < this.width; i++) {
      for (int j = 0; j < this.height; j++) {

        GamePiece gp = this.board.get(i).get(j);

        // gp is at top
        if (j == 0) {
          gp.bottom = true;
        }
        // gp is at bottom
        if (j == (this.height - 1)) {
          gp.top = true;
        }

        // gp is in middle
        if (j != 0 && j != (this.height - 1)) {
          gp.bottom = true;
          gp.top = true;
        }

        // gp is center row
        if (j == this.height / 2) {
          // gp on left side
          if (i == 0) {
            gp.right = true;
          }
          // gp on right side
          else if (i == (this.width - 1)) {
            gp.left = true;
          }
          // gp between sides
          else {
            gp.left = true;
            gp.right = true;
          }
        }
      }
    }
  }

  // generate fractal like board using a subdivision algorithm
  public void fractalGenerate(int startW, int endW, int startH, int endH) {
    int midW = (startW + endW) / 2;
    int midH = (startH + endH) / 2;
    // does nothing if the width or height of current box is less than 2
    if (endW - startW < 2 || endH - startH < 2) {
      return;
    }

    // recurs on half box if height is 2 or 3
    if (endH - startH == 2 || endH - startH == 3) {
      this.fractalGenerate(startW, midW, startH, endH);
      this.fractalGenerate(midW, endW, startH, endH);
    }

    // recurs on quarters of board
    this.fractalGenerate(startW, midW, startH, midH);
    this.fractalGenerate(midW, endW, startH, midH);
    this.fractalGenerate(midW, endW, midH, endH);
    this.fractalGenerate(startW, midW, midH, endH);

    // draws U
    for (int i = startW; i < endW; i++) {
      for (int j = startH; j < endH; j++) {
        GamePiece gp = this.board.get(i).get(j);
        if (i == startW || i == (endW - 1)) {
          if (j == startH) {
            gp.bottom = true;
          }
          else if (j == (endH - 1)) {
            gp.top = true;

            if (i == startW) {
              gp.right = true;
            }
            if (i == (endW - 1)) {
              gp.left = true;
            }

          }
          else {
            gp.top = true;
            gp.bottom = true;
          }
        }
        else {
          if (j == (endH - 1)) {
            gp.left = true;
            gp.right = true;
          }
        }
      }
    }
  }

  // turns on GamePieces with powerStation and branches out
  public void turnOnBoard() {
    for (GamePiece gp : this.nodes) {
      gp.powerLevel = 0;
    }

    GamePiece onPiece = this.board.get(powerCol).get(powerRow);
    this.turnOnGP(onPiece, this.radius);
  }

  // turns on given and connected GP
  public void turnOnGP(GamePiece gp, int numGPLeft) {
    if (numGPLeft == 0) {
      return;
    }
    gp.powerLevel = numGPLeft;

    if (gp.top) {
      if (gp.row > 0) {
        GamePiece topGP = this.board.get(gp.col).get(gp.row - 1);
        if (topGP.bottom && topGP.powerLevel == 0) {
          this.turnOnGP(topGP, numGPLeft - 1);
        }
      }
    }
    if (gp.bottom) {
      if (gp.row < this.height - 1) {
        GamePiece bottomGP = this.board.get(gp.col).get(gp.row + 1);
        if (bottomGP.top && bottomGP.powerLevel == 0) {
          this.turnOnGP(bottomGP, numGPLeft - 1);
        }
      }
    }

    if (gp.right) {
      if (gp.col < this.width - 1) {
        GamePiece rightGP = this.board.get(gp.col + 1).get(gp.row);
        if (rightGP.left && rightGP.powerLevel == 0) {
          this.turnOnGP(rightGP, numGPLeft - 1);
        }
      }
    }
    if (gp.left) {
      if (gp.col > 0) {
        GamePiece leftGP = this.board.get(gp.col - 1).get(gp.row);
        if (leftGP.right && leftGP.powerLevel == 0) {
          this.turnOnGP(leftGP, numGPLeft - 1);
        }
      }
    }
  }
}
