// Queue implementation for breadth-first search
// based on lecture notes
class Queue<T> {
  Deque<T> contents;

  Queue() {
    this.contents = new Deque<>();
  }

  // is this Queue is empty?
  boolean isEmpty() {
    return this.contents.size() == 0;
  }

  // removes an item from this queue
  T remove() {
    return this.contents.removeFromHead();
  }

  // adds item to this queue
  void add(T item) {
    this.contents.addAtTail(item);
  }
}